const calculator = require('./js/calculator/calculator.js')
